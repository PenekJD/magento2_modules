<?php
namespace Penekjd\Controllers\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\Request\Http;

class Upload extends Action implements HttpPostActionInterface
{
    
    public function __construct(
        Context $context,
        private Http $request
    ) {
        parent::__construct($context);
    }

    public function execute()
    {
        $myValue = $this->request->getParam('test_value');

        if ($myValue) {
            return json_encode([
                'success' => true,
                'message' => __('We got the info'),
                'my_value' => $myValue
            ]);
        }
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Penekjd_Controllers::index');
    }
}
